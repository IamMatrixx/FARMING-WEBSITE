// Display a welcome message on page load
window.addEventListener('load', function() {
    alert("Welcome to Pholoentle Farms!");
});

// Highlight the current navigation link based on the current URL
document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll("nav ul li a");
    navLinks.forEach(link => {
        if (link.href === window.location.href) {
            link.style.backgroundColor = "#2a9d8f";
            link.style.borderRadius = "none";
        }
    });
});
// Highlight the current navigation link
document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll("nav ul li a");
    navLinks.forEach(link => {
        if (link.href === window.location.href) {
            link.style.backgroundColor = "#2a9d8f";
            link.style.borderRadius = "none";
        }
    });
});

// Toggle visibility of additional company information
document.addEventListener("DOMContentLoaded", function() {
    const missionSection = document.querySelector(".mission");
    const toggleButton = document.createElement("button");
    toggleButton.textContent = "Learn More About Our Mission";
    toggleButton.style.margin = "20px";
    toggleButton.style.padding = "10px 20px";
    toggleButton.style.fontSize = "1em";
    missionSection.appendChild(toggleButton);

    const missionContent = missionSection.querySelector("p");
    missionContent.style.display = "none";

    toggleButton.addEventListener("click", function() {
        if (missionContent.style.display === "none") {
            missionContent.style.display = "block";
            toggleButton.textContent = "Hide Mission Details";
        } else {
            missionContent.style.display = "none";
            toggleButton.textContent = "Learn More About Our Mission";
        }
    });
});



document.getElementById('customerForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Check if all form fields are valid
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const contact = document.getElementById('contact').value;

    if (name && email && contact) {
        alert('Form submitted successfully!\nThank you for your submission, ' + name + '!');
        this.reset(); // Clear the form after successful submission
    } else {
        alert('Please fill out all fields correctly before submitting.');
    }
});

// Real-time validation feedback
document.getElementById('contact').addEventListener('input', function() {
    const pattern = /^[0-9]{3}-[0-9]{3}-[0-9]{4}$/;
    if (!pattern.test(this.value)) {
        this.setCustomValidity('Please enter the contact number in the format 123-456-7890.');
    } else {
        this.setCustomValidity('');
    }
});
// server.js
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware setup
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/customerData', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

const db = mongoose.connection;
db.on('error', console.error.bind(console, 'Connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

// Define a schema and model
const customerSchema = new mongoose.Schema({
    name: String,
    email: String,
    contact: String,
    updates: Boolean,
});

const Customer = mongoose.model('Customer', customerSchema);

// Endpoint to handle form submissions
app.post('/submit', (req, res) => {
    const newCustomer = new Customer(req.body);

    newCustomer.save((err) => {
        if (err) {
            res.status(500).send('Error saving data');
        } else {
            res.status(200).send('Data saved successfully');
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

function showDetails(name) {
    document.getElementById('team-member-details').textContent = `Details about ${name}`;
    document.getElementById('details-modal').style.display = 'block';
}

function closeModal() {
    document.getElementById('details-modal').style.display = 'none';
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('details-modal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
};
// Highlight navigation links on click
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', function() {
        document.querySelectorAll('nav ul li a').forEach(link => {
            link.classList.remove('active');
        });
        this.classList.add('active');
    });
});

// Add hover effects for images with captions
document.querySelectorAll('.products img').forEach(img => {
    img.addEventListener('mouseover', function() {
        const caption = document.createElement('div');
        caption.className = 'caption';
        caption.textContent = this.alt;
        this.parentElement.appendChild(caption);
    });

    img.addEventListener('mouseout', function() {
        const caption = this.parentElement.querySelector('.caption');
        if (caption) {
            caption.remove();
        }
    });
});

// Expand product details when clicked
document.querySelectorAll('.products li').forEach(product => {
    product.addEventListener('click', function() {
        const details = document.createElement('p');
        details.className = 'details';
        details.textContent = `More information about ${this.textContent}: This product is sustainably sourced and of the highest quality.`;

        // Check if details are already displayed
        if (!this.querySelector('.details')) {
            this.appendChild(details);
        } else {
            this.querySelector('.details').remove();
        }
    });
});
// Highlight navigation links on click
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', function() {
        document.querySelectorAll('nav ul li a').forEach(link => {
            link.classList.remove('active');
        });
        this.classList.add('active');
    });
});

// Add hover effects for images with captions
document.querySelectorAll('.products img').forEach(img => {
    img.addEventListener('mouseover', function() {
        const caption = document.createElement('div');
        caption.className = 'caption';
        caption.textContent = this.alt;
        this.parentElement.appendChild(caption);
    });

    img.addEventListener('mouseout', function() {
        const caption = this.parentElement.querySelector('.caption');
        if (caption) {
            caption.remove();
        }
    });
});

// Expand product details when clicked
document.querySelectorAll('.products li').forEach(product => {
    product.addEventListener('click', function() {
        const details = document.createElement('p');
        details.className = 'details';
        details.textContent = `More information about ${this.textContent}: This product is sustainably sourced and of the highest quality.`;

        // Check if details are already displayed
        if (!this.querySelector('.details')) {
            this.appendChild(details);
        } else {
            this.querySelector('.details').remove();
        }
    });
});